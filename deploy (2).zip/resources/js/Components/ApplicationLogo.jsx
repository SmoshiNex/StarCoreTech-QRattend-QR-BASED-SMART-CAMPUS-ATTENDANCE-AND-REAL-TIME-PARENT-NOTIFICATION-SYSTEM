export default function ApplicationLogo(props) {
    return (
    <></>
    );
}
